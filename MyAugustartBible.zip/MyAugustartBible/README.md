# my augustart Bible

La Bible en français (Louis Segond 1910) et en anglais (World English Bible), dans une même application Android.

## Ce que fait l'application

- **Accueil** : reprise de la dernière lecture, marque-page, livres, recherche, choix de la langue
- **Langues** : Français, English, ou **Les deux** (chaque verset affiché en français, puis en anglais en dessous)
- **Livres et chapitres** : les 66 livres, avec un bouton par chapitre
- **Lecture** : chapitre précédent / suivant, taille du texte réglable (A− / A+), marque-page avec ★
- **Recherche** : mot ou phrase dans la langue choisie (3 lettres minimum)

## Sources des textes (domaine public)

- **Français** : Louis Segond 1910, depuis [eBible.org](https://ebible.org/details.php?id=fraLSG). Fichier `fraLSG_readaloud.zip`.
- **Anglais** : World English Bible, depuis [eBible.org](https://ebible.org/details.php?id=eng-web). Fichier `eng-web_readaloud.zip`.

Les deux traductions sont dans le domaine public. « World English Bible » est une marque d'eBible.org : l'application ne se nomme pas ainsi.

## Où modifier quoi

| Fichier | Contenu |
|---|---|
| `app/src/main/java/com/augustart/bible/MainActivity.kt` | Écrans, langues, lecture, recherche |
| `app/src/main/java/com/augustart/bible/Bible.kt` | Chargement et recherche dans le texte |
| `app/src/main/assets/bible_fr.txt` | Texte français (un verset par ligne) |
| `app/src/main/assets/bible_en.txt` | Texte anglais |
| `app/src/main/res/drawable-nodpi/` | Fond et premier plan du logo |

## Mettre à jour (depuis le téléphone)

1. Ouvrez votre dépôt sur github.com, touchez **Add file**, puis **Upload files**.
2. Choisissez le nouveau **MyAugustartBible.zip** (même nom : il remplace l'ancien), puis **Commit changes**.
3. Ouvrez l'onglet **Actions** : la compilation démarre toute seule (3 à 6 minutes).
4. Quand la ligne est verte, téléchargez **MyAugustartBible-apk**, extrayez le zip et installez **app-debug.apk**.

## Limite connue

La numérotation des versets vient de l'ordre des lignes du texte fourni (les numéros ont été retirés dans ce fichier). Dans certains chapitres, elle peut différer légèrement de l'édition papier.
