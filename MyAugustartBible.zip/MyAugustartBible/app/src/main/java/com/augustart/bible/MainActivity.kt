package com.augustart.bible

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private val BG = Color.parseColor("#0E1020")
private val CARD = Color.parseColor("#1E2240")
private val GOLD = Color.parseColor("#F5C451")
private val TEXT = Color.parseColor("#EDEDF5")
private val MUTED = Color.parseColor("#A9B0C8")

private fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

private fun rounded(color: Int, radius: Float): GradientDrawable {
    val d = GradientDrawable()
    d.setColor(color)
    d.cornerRadius = radius
    return d
}

/**
 * my augustart Bible : la Bible en français et en anglais, dans la même application.
 * Accueil, livres, chapitres, lecture (une langue ou les deux côte à côte), recherche, marque-page.
 */
class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var root: FrameLayout
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()

    private val bibles = HashMap<String, Bible>()

    /** fr, en ou both (les deux langues). */
    private var lang = "fr"
    private var fontSp = 18

    private var current: (() -> View)? = null
    private val history = ArrayList<() -> View>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("bible", MODE_PRIVATE)
        lang = prefs.getString("lang", "fr") ?: "fr"
        fontSp = prefs.getInt("font", 18)

        window.statusBarColor = BG
        window.navigationBarColor = BG
        root = FrameLayout(this)
        root.setBackgroundColor(BG)
        setContentView(root)

        val loading = TextView(this)
        loading.text = "Chargement de la Bible…"
        loading.setTextColor(MUTED)
        loading.textSize = 16f
        loading.gravity = Gravity.CENTER
        show(loading)

        executor.execute {
            val fr = BibleLoader.load(applicationContext, "fr")
            val en = BibleLoader.load(applicationContext, "en")
            handler.post {
                if (fr != null) bibles["fr"] = fr
                if (en != null) bibles["en"] = en
                if (bibles.isEmpty()) {
                    loading.text = "Le texte de la Bible est introuvable dans l'application."
                } else {
                    navigate { home() }
                }
            }
        }
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (history.isNotEmpty()) {
            val prev = history.removeAt(history.size - 1)
            current = prev
            show(prev())
        } else {
            super.onBackPressed()
        }
    }

    // ------------------------------------------------------------------ navigation

    /** Affiche un nouvel écran. replace = true : on remplace l'écran courant (chapitre suivant...). */
    private fun navigate(replace: Boolean = false, render: () -> View) {
        val prev = current
        if (!replace && prev != null) history.add(prev)
        current = render
        show(render())
    }

    /** Redessine l'écran courant (après un changement de langue ou de taille de texte). */
    private fun rerender() {
        val c = current ?: return
        show(c())
    }

    private fun show(v: View) {
        root.removeAllViews()
        root.addView(v, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    // ------------------------------------------------------------------ langues

    /** La Bible principale affichée : français par défaut, anglais si choisi et disponible. */
    private fun mainLang(): String {
        return if (lang == "en" && bibles["en"] != null) "en" else "fr"
    }

    private fun main(): Bible {
        return bibles[mainLang()] ?: bibles.values.first()
    }

    private fun setLang(l: String) {
        if (l != "fr" && bibles["en"] == null) {
            toast("Le texte anglais n'est pas encore ajouté")
            return
        }
        lang = l
        prefs.edit().putString("lang", l).apply()
        rerender()
    }

    // ------------------------------------------------------------------ écrans

    private fun home(): View {
        val col = page()
        col.addView(title("my augustart Bible"))
        col.addView(text("La Parole de Dieu, en français et en anglais", MUTED, 15f), spaced(0, 0, 0, 18))

        val lb = prefs.getInt("lb", 0)
        val lc = prefs.getInt("lc", 1)
        val m = main()
        if (lb in m.bookNames.indices) {
            col.addView(card("Continuer la lecture", m.bookNames[lb] + " " + lc) {
                navigate { reader(lb, lc) }
            })
        }

        val bmb = prefs.getInt("bmb", -1)
        val bmc = prefs.getInt("bmc", -1)
        if (bmb in m.bookNames.indices) {
            col.addView(card("Marque-page", m.bookNames[bmb] + " " + bmc) {
                navigate { reader(bmb, bmc) }
            })
        }

        col.addView(card("Livres de la Bible", m.bookNames.size.toString() + " livres") {
            navigate { books() }
        })
        col.addView(card("Rechercher", "Un mot ou une phrase dans le texte") {
            navigate { search() }
        })

        col.addView(section("Langue"), spaced(0, 14, 0, 6))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(chip("Français", lang == "fr") { setLang("fr") }, weight())
        row.addView(chip("English", lang == "en") { setLang("en") }, weight())
        row.addView(chip("Les deux", lang == "both") { setLang("both") }, weight())
        col.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))

        return scroll(col)
    }

    private fun books(): View {
        val m = main()
        val col = page()
        col.addView(title("Livres"))
        col.addView(text("Touchez un livre pour choisir un chapitre", MUTED, 14f), spaced(0, 0, 0, 10))
        for (i in m.bookNames.indices) {
            col.addView(row(m.bookNames[i], m.chapterCounts[i].toString() + " ch.") {
                navigate { chapters(i) }
            })
        }
        return scroll(col)
    }

    private fun chapters(book: Int): View {
        val m = main()
        val col = page()
        col.addView(title(m.bookNames[book]))
        val count = m.chapterCounts[book]
        var line: LinearLayout? = null
        for (c in 1..count) {
            if ((c - 1) % 5 == 0) {
                val r = LinearLayout(this)
                r.orientation = LinearLayout.HORIZONTAL
                col.addView(r, LinearLayout.LayoutParams(MATCH, WRAP))
                line = r
            }
            val btn = text(c.toString(), TEXT, 17f)
            btn.gravity = Gravity.CENTER
            btn.background = rounded(CARD, dp(12).toFloat())
            btn.setOnClickListener { navigate { reader(book, c) } }
            line?.addView(btn, LinearLayout.LayoutParams(0, dp(54), 1f).apply {
                setMargins(dp(4), dp(4), dp(4), dp(4))
            })
        }
        return scroll(col)
    }

    private fun reader(book: Int, chap: Int): View {
        val m = main()
        val total = m.chapterCounts[book]
        prefs.edit().putInt("lb", book).putInt("lc", chap).apply()

        val col = page()
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.addView(smallButton("‹") {
            if (chap > 1) navigate(replace = true) { reader(book, chap - 1) }
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        val name = text(m.bookNames[book] + " " + chap, GOLD, 17f)
        name.typeface = Typeface.DEFAULT_BOLD
        name.gravity = Gravity.CENTER
        bar.addView(name, LinearLayout.LayoutParams(0, WRAP, 1f))
        bar.addView(smallButton("★") {
            prefs.edit().putInt("bmb", book).putInt("bmc", chap).apply()
            toast("Marque-page enregistré")
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(smallButton("A−") {
            fontSp = Math.max(12, fontSp - 2)
            prefs.edit().putInt("font", fontSp).apply()
            rerender()
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(smallButton("A+") {
            fontSp = Math.min(32, fontSp + 2)
            prefs.edit().putInt("font", fontSp).apply()
            rerender()
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(smallButton("›") {
            if (chap < total) navigate(replace = true) { reader(book, chap + 1) }
        }, LinearLayout.LayoutParams(dp(44), dp(44)))
        col.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))

        val other = if (lang == "both") bibles["en"] else null
        val otherVerses = other?.chapter(book, chap) ?: emptyList()

        for (v in m.chapter(book, chap)) {
            val sb = SpannableStringBuilder()
            sb.append(v.number.toString())
            sb.setSpan(ForegroundColorSpan(GOLD), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.append("  ")
            sb.append(v.text)
            val tv = TextView(this)
            tv.setTextColor(TEXT)
            tv.textSize = fontSp.toFloat()
            tv.setLineSpacing(0f, 1.25f)
            val enText = otherVerses.getOrNull(v.number - 1)?.text
            if (enText != null) {
                val start = sb.length
                sb.append("\n")
                sb.append(enText)
                sb.setSpan(ForegroundColorSpan(MUTED), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                sb.setSpan(StyleSpan(android.graphics.Typeface.ITALIC), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                tv.textSize = (fontSp - 2).toFloat()
            }
            tv.text = sb
            col.addView(tv, spaced(0, 0, 0, 12))
        }

        // Chapitre précédent / suivant en bas
        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.addView(navButton("‹ Chapitre précédent", chap > 1) {
            navigate(replace = true) { reader(book, chap - 1) }
        }, weight())
        nav.addView(navButton("Chapitre suivant ›", chap < total) {
            navigate(replace = true) { reader(book, chap + 1) }
        }, weight())
        col.addView(nav, spaced(0, 12, 0, 24))
        return scroll(col)
    }

    private fun search(): View {
        val col = page()
        col.addView(title("Rechercher"))
        val input = EditText(this)
        input.hint = "Mot ou phrase (3 lettres minimum)"
        input.setHintTextColor(MUTED)
        input.setTextColor(TEXT)
        input.textSize = 16f
        input.setSingleLine(true)
        input.imeOptions = EditorInfo.IME_ACTION_SEARCH
        input.background = rounded(CARD, dp(14).toFloat())
        input.setPadding(dp(16), dp(12), dp(16), dp(12))
        col.addView(input, LinearLayout.LayoutParams(MATCH, WRAP))

        val results = LinearLayout(this)
        results.orientation = LinearLayout.VERTICAL
        col.addView(results, spaced(0, 12, 0, 0))

        val doSearch = {
            val q = input.text.toString().trim()
            results.removeAllViews()
            if (q.length < 3) {
                toast("Tapez au moins 3 lettres")
            } else {
                val m = main()
                val found = m.search(q, 100)
                val label = if (found.size >= 100) "Plus de 100 résultats, les 100 premiers :" else found.size.toString() + " résultat(s)"
                results.addView(text(label, MUTED, 14f), spaced(0, 0, 0, 8))
                for (v in found) {
                    val snippet = if (v.text.length > 110) v.text.substring(0, 110) + "…" else v.text
                    val where = m.bookNames[v.book] + " " + v.chapter + ":" + v.number
                    results.addView(row(where, snippet) {
                        navigate { reader(v.book, v.chapter) }
                    })
                }
            }
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(input.windowToken, 0)
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                doSearch()
                true
            } else {
                false
            }
        }
        return scroll(col)
    }

    // ------------------------------------------------------------------ éléments d'interface

    private fun page(): LinearLayout {
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(20), dp(16), dp(16))
        return col
    }

    private fun scroll(child: View): View {
        val sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false
        sv.setBackgroundColor(BG)
        sv.addView(child, FrameLayout.LayoutParams(MATCH, WRAP))
        return sv
    }

    private fun title(t: String): TextView {
        val tv = text(t, TEXT, 28f)
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setPadding(0, 0, 0, dp(10))
        return tv
    }

    private fun section(t: String): TextView {
        val tv = text(t.uppercase(), MUTED, 12f)
        tv.typeface = Typeface.DEFAULT_BOLD
        return tv
    }

    private fun text(t: String, color: Int, size: Float): TextView {
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(color)
        tv.textSize = size
        return tv
    }

    private fun card(title: String, sub: String, onClick: () -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = rounded(CARD, dp(18).toFloat())
        box.setPadding(dp(18), dp(16), dp(18), dp(16))
        val t = text(title, TEXT, 18f)
        t.typeface = Typeface.DEFAULT_BOLD
        box.addView(t)
        box.addView(text(sub, MUTED, 14f))
        box.setOnClickListener { onClick() }
        box.isClickable = true
        box.setPadding(dp(18), dp(16), dp(18), dp(16))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.bottomMargin = dp(12)
        box.layoutParams = lp
        return box
    }

    /** Une ligne cliquable : titre à gauche, petit texte dessous. */
    private fun row(title: String, sub: String, onClick: () -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.background = rounded(CARD, dp(12).toFloat())
        box.setPadding(dp(14), dp(12), dp(14), dp(12))
        val t = text(title, TEXT, 16f)
        t.typeface = Typeface.DEFAULT_BOLD
        box.addView(t)
        if (sub.isNotEmpty()) box.addView(text(sub, MUTED, 13f))
        box.setOnClickListener { onClick() }
        box.isClickable = true
        box.setPadding(dp(14), dp(12), dp(14), dp(12))
        box.layoutParams = spaced(0, 0, 0, 8)
        return box
    }

    private fun chip(label: String, selected: Boolean, onClick: () -> Unit): TextView {
        val tv = text(label, if (selected) BG else TEXT, 14f)
        tv.gravity = Gravity.CENTER
        tv.typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        tv.background = rounded(if (selected) GOLD else CARD, dp(20).toFloat())
        tv.setOnClickListener { onClick() }
        tv.setPadding(dp(6), dp(10), dp(6), dp(10))
        return tv
    }

    private fun smallButton(label: String, onClick: () -> Unit): TextView {
        val tv = text(label, TEXT, 18f)
        tv.gravity = Gravity.CENTER
        tv.background = rounded(CARD, dp(12).toFloat())
        tv.setOnClickListener { onClick() }
        return tv
    }

    private fun navButton(label: String, enabled: Boolean, onClick: () -> Unit): TextView {
        val tv = text(label, if (enabled) GOLD else MUTED, 14f)
        tv.gravity = Gravity.CENTER
        tv.background = rounded(CARD, dp(12).toFloat())
        tv.setPadding(dp(8), dp(12), dp(8), dp(12))
        if (enabled) tv.setOnClickListener { onClick() }
        return tv
    }

    private fun weight(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, WRAP, 1f)
        lp.setMargins(dp(3), dp(4), dp(3), dp(4))
        return lp
    }

    private fun spaced(l: Int, t: Int, r: Int, b: Int): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.setMargins(dp(l), dp(t), dp(r), dp(b))
        return lp
    }
}
