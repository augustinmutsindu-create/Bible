package com.augustart.bible

import android.content.Context

/** Un verset : livre (index), chapitre, numéro, texte. */
class Verse(val book: Int, val chapter: Int, val number: Int, val text: String)

/** Une Bible complète dans une langue. */
class Bible(
    val lang: String,
    val bookNames: List<String>,
    val chapterCounts: IntArray,
    private val verses: List<Verse>
) {
    private val byChapter = HashMap<Int, ArrayList<Verse>>()

    init {
        for (v in verses) {
            byChapter.getOrPut(key(v.book, v.chapter)) { ArrayList() }.add(v)
        }
    }

    fun chapter(book: Int, chap: Int): List<Verse> {
        return byChapter[key(book, chap)] ?: emptyList()
    }

    /** Cherche un texte dans tous les versets (sans tenir compte de la casse). */
    fun search(query: String, limit: Int): List<Verse> {
        val needle = query.trim().lowercase()
        val out = ArrayList<Verse>()
        if (needle.isEmpty()) return out
        for (v in verses) {
            if (v.text.lowercase().contains(needle)) {
                out.add(v)
                if (out.size >= limit) break
            }
        }
        return out
    }

    companion object {
        fun key(book: Int, chap: Int): Int = book * 1000 + chap
    }
}

/** Charge le fichier texte bible_<langue>.txt depuis les ressources de l'application. */
object BibleLoader {
    fun load(context: Context, lang: String): Bible? {
        return try {
            context.assets.open("bible_$lang.txt").bufferedReader(Charsets.UTF_8).use { reader ->
                parse(lang, reader.lineSequence())
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun parse(lang: String, lines: Sequence<String>): Bible {
        val names = ArrayList<String>()
        val counts = ArrayList<Int>()
        val verses = ArrayList<Verse>()
        for (line in lines) {
            if (line.isEmpty()) continue
            val p = line.split('\t')
            when (p[0]) {
                "B" -> {
                    names.add(p[2])
                    counts.add(p[3].toInt())
                }
                "V" -> {
                    val text = p.subList(4, p.size).joinToString("\t")
                    verses.add(Verse(p[1].toInt(), p[2].toInt(), p[3].toInt(), text))
                }
            }
        }
        return Bible(lang, names, counts.toIntArray(), verses)
    }
}
