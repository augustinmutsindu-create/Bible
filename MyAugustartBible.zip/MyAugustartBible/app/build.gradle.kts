plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.augustart.bible"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.augustart.bible"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    // Clé de signature fixe : chaque nouvelle version s'installe par-dessus la précédente
    // sans devoir désinstaller l'application (clé personnelle, pas pour le Play Store).
    signingConfigs {
        getByName("debug") {
            storeFile = file("augustart-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
